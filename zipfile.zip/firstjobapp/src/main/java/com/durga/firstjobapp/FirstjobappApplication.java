package com.durga.firstjobapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstjobappApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstjobappApplication.class, args);
	}

}
